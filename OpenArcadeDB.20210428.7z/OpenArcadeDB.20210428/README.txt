Obtained from https://github.com/xovox/OpenArcadeDB
