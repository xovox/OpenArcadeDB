This file was obtained from https://github.com/xovox/OpenArcadeDB
